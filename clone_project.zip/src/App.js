import React, { Component } from 'react'
import './App.css';


import MainComponent from './component/MainComponent';
import IspDigital from './component/pages/IspDigital';
import {
  createBrowserRouter,
  RouterProvider,
} from "react-router-dom";
import Body from './Body';
import Soft_Development from './component/pages/SoftDevelopment';


const router = createBrowserRouter(

  [
    {
      path: "/",
      element: <><Body /></>,
      errorElement: <>error occurs</>,
      children: [
        {
          index: true,
          element: <MainComponent />,
        },
        {
          path: "/ispDigital",
          element: <><IspDigital /></>,
        },
        {
          path: "/softDevelopment",
          element: <><Soft_Development/></>,
        },
      ],
    },
    // {
    //   path: "/ispDigital",
    //   element: <><IspDigital /></>,
    // },
  ]);

export class App extends Component {
  // cloned from here = https://softifybd.com/

  render() {
    return (
      <>

        {/* <Navbar  /> */}
        <RouterProvider router={router} />
        {/* <Footer /> */}
      </>
    )
  }
}

export default App